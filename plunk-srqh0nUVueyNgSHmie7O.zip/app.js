var app = angular.module('plunker', []);

app.controller('MainCtrl', function($scope,$http) {
  
  
  $http.get("priya.json").then(function (response) {
      $scope.card = response.data;
  });
        
$scope.myvalue = false;

  $scope.showAlert = function(){
    $scope.myvalue = true;  
  };
  
  

  
});
