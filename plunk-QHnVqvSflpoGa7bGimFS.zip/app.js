var app = angular.module('plunker', []);

app.controller('MainCtrl', function($scope,$http) {
  
    $scope.add = function () {
    $scope.information.push({'userId':$scope.userId,'id':$scope.id,'title':$scope.tiltle,'completed':$scope.completed});
    $scope.userId='';
    $scope.id='';
    $scope.title='';
    $scope.completed='';
    
    
  };
  
  $scope.remove=function(index){
    $scope.information.splice(index,1);
    
  };
    
  
  
   $http.get("details.json").then(function(response) {
      $scope.information = response.data;
  });
        
});
